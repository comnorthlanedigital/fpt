# JB'S Pro Painters – handoff for the next builder

## Client (facts only – never invent more)
- **JB'S Pro Painters LLC**, owner **Jonathan Bernal**. Owner-operated, **licensed and insured**.
- Phone/text **(602) 473-0415** (`tel:+16024730415`), email **jbspropainters@gmail.com**.
- Facebook: https://www.facebook.com/profile.php?id=61584288311213
- Areas: **Gilbert, Mesa, Chandler, Tempe, Scottsdale, Queen Creek** (East Valley, AZ).
- Services: exterior (stucco, trim, garage doors), interior (walls, ceilings, doors, trim), cabinet refinishing, doors & wood stain, commercial repaints (restaurants, warehouses, shops), accent walls/stripes.
- Tagline from his logo: "Quality, precision, perfection". Free estimates.
- One real review only: "JB'S Pro Painters LLC did an outstanding job painting the exterior…" – Kenneth R., Facebook (excerpt).
- **Not confirmed (do not claim):** years in business, license number, review counts/stars, warranty, same-day quotes, inspections, touch-up kit, prices, offers, address.

## Brand / design rules
- Logo colors: **navy #0a1433 / #050a1c, blue #2459e6 (accent #7da3ff), silver #d5dcea**. User hates "too much white", "AI slop", fat buttons, ugly fonts, boring headers.
- Fonts used: Gilda Display (headings) + Onest (body), embedded base64 (`assets/fonts/home.css`).
- Mobile first, sticky Call / Text / Free estimate bar on phones, test at 390px and 1440px.
- Tap a project photo to flip **after ↔ before** (he asked for this instead of the old roller reveal).
- Don't copy competitor sites' text/photos (he showed arizonapaintingcompany.com as inspiration: numbered promise cards, photo service tiles, reviews block, sticky bottom nav – layout ideas only).
- Run the launch checklist in `CLAUDE.md` before calling a site done.

## What exists (in this zip)
- `latest/JBS-revision.html` – most complete design: project reel hero, 2-step estimate form, 4 numbered promises, photo service tiles, owner, FAQ.
- `latest/JBS-clean-base.html` – the user's own template (`template.html`) filled with JB'S content. **User's most recent ask.**
- `latest/JBS-new-2-reel.html` – earlier reel version.
- `build/` – Python generators (`revision-build.py`, `clean-base-build.py`, `template.html`). They expect images in `../v3/img` and fonts in `../v3/fonts`; adjust paths to `assets/`.
- `assets/img/` – all real photos (`*-before/after.jpg`, `-sm` = small). Key: bath, home (Gilbert exterior), kitchen (Queen Creek cabinets), door, gdoor (garage doors), tl (restaurant, commercial), stripe (accent wall), `owner-new.jpg` (Jonathan in truck), `logo-sq.jpg`, `logo3d.jpg`, `og.jpg` (1200x630).
- Forms: Netlify Forms (`name="quote"`, honeypot `bot`, hidden detection form at top of body). Deploy by Netlify Drop (zip with index.html).

## Open items / waiting on Jonathan
1. New photos, incl. owner photo in company shirt (swap into owner section).
2. Which promises he really keeps (to fill 6 numbered cards).
3. Confirm "details we take care of" drafts (prep first, space protected, straight answers, done right).
4. Pick a final design → make Netlify zip + privacy/terms, 404, sitemap/robots, real domain/canonical, analytics if wanted.
5. Later (see `NOTES-jonathan-requests.md`): Google Business Profile verification, contractor contacts, professional estimates/invoices, contract template w/ warranty (needs his terms + lawyer review). He prefers calls/texts.
